from openai import OpenAI
import json
import sqlite3

import esg_summary_prompt

api_base = "https://genai-llm-gw.anigenailabs01.aws.prod.au.internal.cba"  # litellm server

client = OpenAI(
    base_url=api_base,
    api_key= "API key"
)

clients_selected = "Desktop/BankingAdvisor_DataSet/Clients/C010.json"

with open(clients_selected, "r") as file:
    client_data = json.load(file)

client_id = client_data["client_profile"]["client_id"]
client_info_str = json.dumps(client_data)

content = esg_summary_prompt.outcome_prompt(client_info_str)  # Replace this with the function that generates the prompt

## Change the model parameter to call gpt-4o,bedrock-claude-sonnet,bedrock-claude-haiku etc
response = client.chat.completions.create(
    model="gpt-4o-mini_v2024-07-18",  # Replace this with model from the current catalogue e.g gpt-3.5-turbo,gpt-4o,bedrock-claude-sonnet,bedrock-claude-haiku,mistral-instruct7b,mixtral-8x7b-instruct,mixtral-large
    messages=[{"role": "user", "content": content}],
    stream=True,
)

def transform_response_to_str(llm_output):
    response_content = ""
    for chunk in llm_output:
        response_content += chunk.choices[0].delta.content or ""
    try:
        response_json = json.loads(response_content)
        response_str = json.dumps(response_json, indent=1)
    except Exception as e:
        print(f"Error occured, please retry: {e}")
        response_str = None
    return response_str

esg_summary = transform_response_to_str(response)


conn = sqlite3.connect("BankingAdvisorData.db")
cursor = conn.cursor()

# Update ESG summary for this client
cursor.execute(
    "UPDATE clients SET esg_summary = ? WHERE client_id = ?",
    (esg_summary, client_id)
)

conn.commit()
conn.close()