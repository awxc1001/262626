import json
from flask import Flask, jsonify, request
from flask_cors import CORS
import mysql.connector

app = Flask(__name__)

# Enable CORS for all routes
CORS(app)

def get_db_connection():
    """Establishes a connection to the MySQL database."""
    mysql_conn = mysql.connector.connect(
        host='localhost',
        user='user1',
        password='user1',
        database='BankingAdvisorData',
        port=3306
    )
    return mysql_conn

# Endpoint to search the client's info
@app.route('/<clientId>/search', methods=['GET'])
def get_profile(clientId):
    """Fetches client profile information based on clientId."""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT client_info FROM clients WHERE client_id = %s", (clientId,))
    row = cursor.fetchone()
    cursor.close()
    conn.close()
    if row:
        client_info = json.loads(row['client_info'])
        return client_info
    else:
        return jsonify({"error": "Client not found"}), 404

# Endpoint to get the client's ESG summary
@app.route('/<clientId>/esg', methods=['GET'])
def get_esg(clientId):
    """Fetches ESG summary for a client based on clientId."""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT esg_summary FROM clients WHERE client_id = %s", (clientId,))
    row = cursor.fetchone()
    cursor.close()
    conn.close()
    if row:
        return json.loads(row["esg_summary"])
    else:
        return jsonify({"error": "Client not found"}), 404

# Endpoint to get the client's product recommendations
@app.route('/<clientId>/product', methods=['GET'])
def get_product_output(clientId):
    """Fetches product recommendations for a client based on clientId."""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT product_update FROM clients WHERE client_id = %s", (clientId,))
    row = cursor.fetchone()
    cursor.close()
    conn.close()
    if row:
        return json.loads(row["product_update"])
    else:
        return jsonify({"error": "Client not found"}), 404

# Endpoint to get the events that are relevant to the client
@app.route('/<clientId>/event', methods=['GET'])
def get_event_output(clientId):
    """Fetches event updates for a client based on clientId."""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT event_update FROM clients WHERE client_id = %s", (clientId,))
    row = cursor.fetchone()
    cursor.close()
    conn.close()
    if row:
        return json.loads(row["event_update"])
    else:
        return jsonify({"error": "Client not found"}), 404

if __name__ == '__main__':
    # Run the Flask application
    app.run(host='0.0.0.0', port=8001)